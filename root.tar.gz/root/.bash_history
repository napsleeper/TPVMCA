 poweroff
 poweroff
mount -0 remount,rw /
mount -0 remount,rw /
mount -o remount,rw /
passwd
exec /sbin/init
