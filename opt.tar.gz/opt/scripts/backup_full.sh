#!/bin/bash

# ===== AYUDA =====
if [ "$1" == "-help" ]; then
	echo "Uso: $0 ORIGEN DESTINO"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

# ===== VALIDAR PARAMETROS =====
if [ $# -ne 2 ]; then
	echo "Error: Debes de indicar origen y destino"
	echo "Usa -help para ayuda"
	exit 1
fi

ORIGEN=$1
DESTINO=$2

# ===== VALIDAR EXISTENCIA =====
if [ ! -d "$ORIGEN" ]; then
	echo "Error: el origen no existe"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: El destino no existe"
	exit 1
fi

# ===== FECHA  ======
FECHA=$(date +%Y%m%d%)

# ===== NOMBRE ARCHIVO =====
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# ===== BACKUP =====
tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

# ===== RESULTADO =====
echo "Backup creado en $DESTINO/$ARCHIVO"

